# IP Review:

 - Jody Garnett July 10th, 2006

 - Adrian Custer June 2008

STATUS: DIRTY

* Code is Clean, with one(two?) confused (C) issues
* http://jira.codehaus.org/browse/GEOT-1892


The Graph module was started as part of the Java Confulation Project, this 
port was made avaialable to the GeoTools community and feature module by 
Refractions Research as part of the Validating

Web Feature Server project funded by GeoConnections Canada. Earlier versions 
of this library were released under GPL to the JCP (a series of JUMP plugins). 
Refractions Research retained copyright and donated the port to GeoTools in 
2003.

```
org.geotools.graph.build
org.geotools.graph.build.basic
org.geotools.graph.build.line
org.geotools.graph.build.opt
org.geotools.graph.build.polygon
org.geotools.graph.io
org.geotools.graph.io.standard
org.geotools.graph.path
org.geotools.graph.structure
org.geotools.graph.structure.basic
org.geotools.graph.structure.line
org.geotools.graph.structure.opt
org.geotools.graph.traverse
org.geotools.graph.traverse.basic
org.geotools.graph.traverse.standard
```


```
org.geotools.graph.util
```

 - StringUtil which contains an earlier header:

```
/*
 {DOLLAR} Id {DOLLAR}

  Copyright (c) 2003, Ministry of Sustainable Resource Management
   Government of British Columbia, Canada

   All rights reserved.
   This information contained herein may not be used in whole
   or in part without the express written consent of the
   Government of British Columbia, Canada.
*/
```

```
org.geotools.graph.util.deluanay
org.geotools.graph.util.geom
org.geotools.graph.util.graph
```

``
* (test)
``