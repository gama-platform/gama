/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.fes20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Selection Clause Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.fes20.Fes20Package#getAbstractSelectionClauseType()
 * @model abstract="true"
 *        extendedMetaData="name='AbstractSelectionClauseType' kind='empty'"
 * @generated
 */
public interface AbstractSelectionClauseType extends EObject {
} // AbstractSelectionClauseType
