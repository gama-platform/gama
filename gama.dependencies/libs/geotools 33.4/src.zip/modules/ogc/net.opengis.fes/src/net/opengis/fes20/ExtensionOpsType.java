/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.fes20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extension Ops Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.fes20.Fes20Package#getExtensionOpsType()
 * @model abstract="true"
 *        extendedMetaData="name='ExtensionOpsType' kind='empty'"
 * @generated
 */
public interface ExtensionOpsType extends EObject {
} // ExtensionOpsType
