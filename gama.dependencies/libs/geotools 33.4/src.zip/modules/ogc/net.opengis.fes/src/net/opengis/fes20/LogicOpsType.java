/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.fes20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logic Ops Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.fes20.Fes20Package#getLogicOpsType()
 * @model abstract="true"
 *        extendedMetaData="name='LogicOpsType' kind='empty'"
 * @generated
 */
public interface LogicOpsType extends EObject {
} // LogicOpsType
