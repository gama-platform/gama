/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.fes20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Operators Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.fes20.Fes20Package#getLogicalOperatorsType()
 * @model extendedMetaData="name='LogicalOperators_._type' kind='empty'"
 * @generated
 */
public interface LogicalOperatorsType extends EObject {
} // LogicalOperatorsType
