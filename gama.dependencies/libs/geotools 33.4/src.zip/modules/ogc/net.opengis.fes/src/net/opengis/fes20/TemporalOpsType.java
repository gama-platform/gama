/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.fes20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Temporal Ops Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.fes20.Fes20Package#getTemporalOpsType()
 * @model abstract="true"
 *        extendedMetaData="name='TemporalOpsType' kind='empty'"
 * @generated
 */
public interface TemporalOpsType extends EObject {
} // TemporalOpsType
