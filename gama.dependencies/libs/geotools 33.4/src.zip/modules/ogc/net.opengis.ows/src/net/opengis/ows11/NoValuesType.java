/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.ows11;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>No Values Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.ows11.Ows11Package#getNoValuesType()
 * @model extendedMetaData="name='NoValues_._type' kind='empty'"
 * @generated
 */
public interface NoValuesType extends EObject {
} // NoValuesType
