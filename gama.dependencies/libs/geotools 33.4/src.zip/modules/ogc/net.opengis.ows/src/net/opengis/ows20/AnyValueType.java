/**
 */
package net.opengis.ows20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Any Value Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.ows20.Ows20Package#getAnyValueType()
 * @model extendedMetaData="name='AnyValue_._type' kind='empty'"
 * @generated
 */
public interface AnyValueType extends EObject {
} // AnyValueType
