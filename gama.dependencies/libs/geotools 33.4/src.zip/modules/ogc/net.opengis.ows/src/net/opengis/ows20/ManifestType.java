/**
 */
package net.opengis.ows20;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Manifest Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Unordered list of one or more groups of references to
 *       remote and/or local resources.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link net.opengis.ows20.ManifestType#getReferenceGroup <em>Reference Group</em>}</li>
 * </ul>
 *
 * @see net.opengis.ows20.Ows20Package#getManifestType()
 * @model extendedMetaData="name='ManifestType' kind='elementOnly'"
 * @generated
 */
public interface ManifestType extends BasicIdentificationType {
    /**
   * Returns the value of the '<em><b>Reference Group</b></em>' containment reference list.
   * The list contents are of type {@link net.opengis.ows20.ReferenceGroupType}.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Reference Group</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Reference Group</em>' containment reference list.
   * @see net.opengis.ows20.Ows20Package#getManifestType_ReferenceGroup()
   * @model containment="true" required="true"
   *        extendedMetaData="kind='element' name='ReferenceGroup' namespace='##targetNamespace'"
   * @generated
   */
    EList<ReferenceGroupType> getReferenceGroup();

} // ManifestType
