/**
 */
package net.opengis.ows20;

import org.eclipse.emf.ecore.EObject;

import org.w3.xlink.ActuateType;
import org.w3.xlink.ShowType;
import org.w3.xlink.TypeType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Online Resource Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Reference to on-line resource from which data can be
 *       obtained.
 * For OWS use in the service metadata document, the
 *       CI_OnlineResource class was XML encoded as the attributeGroup
 *       "xlink:simpleAttrs", as used in GML.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getActuate <em>Actuate</em>}</li>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getArcrole <em>Arcrole</em>}</li>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getHref <em>Href</em>}</li>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getRole <em>Role</em>}</li>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getShow <em>Show</em>}</li>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getTitle <em>Title</em>}</li>
 *   <li>{@link net.opengis.ows20.OnlineResourceType#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see net.opengis.ows20.Ows20Package#getOnlineResourceType()
 * @model extendedMetaData="name='OnlineResourceType' kind='empty'"
 * @generated
 */
public interface OnlineResourceType extends EObject {
    /**
   * Returns the value of the '<em><b>Actuate</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Actuate</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Actuate</em>' attribute.
   * @see #isSetActuate()
   * @see #unsetActuate()
   * @see #setActuate(ActuateType)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Actuate()
   * @model unsettable="true" dataType="net.opengis.ows20.ActuateType"
   *        extendedMetaData="kind='attribute' name='actuate' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    ActuateType getActuate();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getActuate <em>Actuate</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Actuate</em>' attribute.
   * @see #isSetActuate()
   * @see #unsetActuate()
   * @see #getActuate()
   * @generated
   */
    void setActuate(ActuateType value);

    /**
   * Unsets the value of the '{@link net.opengis.ows20.OnlineResourceType#getActuate <em>Actuate</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @see #isSetActuate()
   * @see #getActuate()
   * @see #setActuate(ActuateType)
   * @generated
   */
    void unsetActuate();

    /**
   * Returns whether the value of the '{@link net.opengis.ows20.OnlineResourceType#getActuate <em>Actuate</em>}' attribute is set.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @return whether the value of the '<em>Actuate</em>' attribute is set.
   * @see #unsetActuate()
   * @see #getActuate()
   * @see #setActuate(ActuateType)
   * @generated
   */
    boolean isSetActuate();

    /**
   * Returns the value of the '<em><b>Arcrole</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Arcrole</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Arcrole</em>' attribute.
   * @see #setArcrole(String)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Arcrole()
   * @model dataType="net.opengis.ows20.ArcroleType_2"
   *        extendedMetaData="kind='attribute' name='arcrole' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    String getArcrole();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getArcrole <em>Arcrole</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Arcrole</em>' attribute.
   * @see #getArcrole()
   * @generated
   */
    void setArcrole(String value);

    /**
   * Returns the value of the '<em><b>Href</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Href</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Href</em>' attribute.
   * @see #setHref(String)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Href()
   * @model dataType="net.opengis.ows20.HrefType_2"
   *        extendedMetaData="kind='attribute' name='href' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    String getHref();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getHref <em>Href</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Href</em>' attribute.
   * @see #getHref()
   * @generated
   */
    void setHref(String value);

    /**
   * Returns the value of the '<em><b>Role</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Role</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Role</em>' attribute.
   * @see #setRole(String)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Role()
   * @model dataType="net.opengis.ows20.RoleType_2"
   *        extendedMetaData="kind='attribute' name='role' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    String getRole();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getRole <em>Role</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Role</em>' attribute.
   * @see #getRole()
   * @generated
   */
    void setRole(String value);

    /**
   * Returns the value of the '<em><b>Show</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Show</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Show</em>' attribute.
   * @see #isSetShow()
   * @see #unsetShow()
   * @see #setShow(ShowType)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Show()
   * @model unsettable="true" dataType="net.opengis.ows20.ShowType"
   *        extendedMetaData="kind='attribute' name='show' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    ShowType getShow();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getShow <em>Show</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Show</em>' attribute.
   * @see #isSetShow()
   * @see #unsetShow()
   * @see #getShow()
   * @generated
   */
    void setShow(ShowType value);

    /**
   * Unsets the value of the '{@link net.opengis.ows20.OnlineResourceType#getShow <em>Show</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @see #isSetShow()
   * @see #getShow()
   * @see #setShow(ShowType)
   * @generated
   */
    void unsetShow();

    /**
   * Returns whether the value of the '{@link net.opengis.ows20.OnlineResourceType#getShow <em>Show</em>}' attribute is set.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @return whether the value of the '<em>Show</em>' attribute is set.
   * @see #unsetShow()
   * @see #getShow()
   * @see #setShow(ShowType)
   * @generated
   */
    boolean isSetShow();

    /**
   * Returns the value of the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Title</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Title</em>' attribute.
   * @see #setTitle(String)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Title()
   * @model dataType="net.opengis.ows20.TitleAttrType_2"
   *        extendedMetaData="kind='attribute' name='title' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    String getTitle();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getTitle <em>Title</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Title</em>' attribute.
   * @see #getTitle()
   * @generated
   */
    void setTitle(String value);

    /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * The default value is <code>"simple"</code>.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Type</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see #isSetType()
   * @see #unsetType()
   * @see #setType(TypeType)
   * @see net.opengis.ows20.Ows20Package#getOnlineResourceType_Type()
   * @model default="simple" unsettable="true" dataType="net.opengis.ows20.TypeType"
   *        extendedMetaData="kind='attribute' name='type' namespace='http://www.w3.org/1999/xlink'"
   * @generated
   */
    TypeType getType();

    /**
   * Sets the value of the '{@link net.opengis.ows20.OnlineResourceType#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see #isSetType()
   * @see #unsetType()
   * @see #getType()
   * @generated
   */
    void setType(TypeType value);

    /**
   * Unsets the value of the '{@link net.opengis.ows20.OnlineResourceType#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @see #isSetType()
   * @see #getType()
   * @see #setType(TypeType)
   * @generated
   */
    void unsetType();

    /**
   * Returns whether the value of the '{@link net.opengis.ows20.OnlineResourceType#getType <em>Type</em>}' attribute is set.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @return whether the value of the '<em>Type</em>' attribute is set.
   * @see #unsetType()
   * @see #getType()
   * @see #setType(TypeType)
   * @generated
   */
    boolean isSetType();

} // OnlineResourceType
