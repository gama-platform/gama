/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.wfs20;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Create Stored Query Response Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.wfs20.Wfs20Package#getCreateStoredQueryResponseType()
 * @model extendedMetaData="name='CreateStoredQueryResponseType' kind='empty'"
 * @generated
 */
public interface CreateStoredQueryResponseType extends ExecutionStatusType {
} // CreateStoredQueryResponseType
