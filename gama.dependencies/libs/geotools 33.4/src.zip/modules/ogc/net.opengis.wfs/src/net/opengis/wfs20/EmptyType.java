/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.wfs20;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Empty Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.wfs20.Wfs20Package#getEmptyType()
 * @model extendedMetaData="name='EmptyType' kind='empty'"
 * @generated
 */
public interface EmptyType extends EObject {
} // EmptyType
