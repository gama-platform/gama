/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.wfs20;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>List Stored Queries Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see net.opengis.wfs20.Wfs20Package#getListStoredQueriesType()
 * @model extendedMetaData="name='ListStoredQueriesType' kind='empty'"
 * @generated
 */
public interface ListStoredQueriesType extends BaseRequestType {
} // ListStoredQueriesType
