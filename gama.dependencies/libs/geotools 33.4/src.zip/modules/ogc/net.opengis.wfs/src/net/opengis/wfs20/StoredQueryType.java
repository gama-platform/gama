/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package net.opengis.wfs20;

import net.opengis.fes20.AbstractQueryExpressionType;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stored Query Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link net.opengis.wfs20.StoredQueryType#getParameter <em>Parameter</em>}</li>
 *   <li>{@link net.opengis.wfs20.StoredQueryType#getId <em>Id</em>}</li>
 * </ul>
 *
 * @see net.opengis.wfs20.Wfs20Package#getStoredQueryType()
 * @model extendedMetaData="name='StoredQueryType' kind='elementOnly'"
 * @generated
 */
public interface StoredQueryType extends AbstractQueryExpressionType {
    /**
   * Returns the value of the '<em><b>Parameter</b></em>' containment reference list.
   * The list contents are of type {@link net.opengis.wfs20.ParameterType}.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Parameter</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Parameter</em>' containment reference list.
   * @see net.opengis.wfs20.Wfs20Package#getStoredQueryType_Parameter()
   * @model containment="true"
   *        extendedMetaData="kind='element' name='Parameter' namespace='##targetNamespace'"
   * @generated
   */
    EList<ParameterType> getParameter();

    /**
   * Returns the value of the '<em><b>Id</b></em>' attribute.
   * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Id</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
   * @return the value of the '<em>Id</em>' attribute.
   * @see #setId(String)
   * @see net.opengis.wfs20.Wfs20Package#getStoredQueryType_Id()
   * @model dataType="org.eclipse.emf.ecore.xml.type.AnyURI" required="true"
   *        extendedMetaData="kind='attribute' name='id'"
   * @generated
   */
    String getId();

    /**
   * Sets the value of the '{@link net.opengis.wfs20.StoredQueryType#getId <em>Id</em>}' attribute.
   * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
   * @param value the new value of the '<em>Id</em>' attribute.
   * @see #getId()
   * @generated
   */
    void setId(String value);

} // StoredQueryType
