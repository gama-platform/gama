/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.fory.resolver;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.annotation.concurrent.ThreadSafe;
import org.apache.fory.collection.Tuple2;
import org.apache.fory.exception.InsecureException;
import org.apache.fory.logging.Logger;
import org.apache.fory.logging.LoggerFactory;
import org.apache.fory.type.TypeUtils;

/** Class checker backed by allow and disallow lists. */
@ThreadSafe
public class AllowListChecker implements TypeChecker {
  private static final Logger LOG = LoggerFactory.getLogger(AllowListChecker.class);

  public enum CheckLevel {
    /** Disable class-name checks. */
    DISABLE,

    /** Deny disallowed classes and warn about classes outside the allow list. */
    WARN,

    /** Allow only classes in the allow list. */
    STRICT
  }

  private volatile CheckLevel checkLevel;
  private final Set<String> allowList;
  private final Set<String> allowListPrefix;
  private final Set<String> disallowList;
  private final Set<String> disallowListPrefix;
  private final transient WeakHashMap<TypeResolver, Boolean> listeners;
  private final transient ReadWriteLock lock;

  public AllowListChecker() {
    this(CheckLevel.WARN);
  }

  public AllowListChecker(CheckLevel checkLevel) {
    this.checkLevel = checkLevel;
    allowList = new HashSet<>();
    allowListPrefix = new HashSet<>();
    disallowList = new HashSet<>();
    disallowListPrefix = new HashSet<>();
    lock = new ReentrantReadWriteLock();
    listeners = new WeakHashMap<>();
  }

  public CheckLevel getCheckLevel() {
    return checkLevel;
  }

  public void setCheckLevel(CheckLevel checkLevel) {
    try {
      lock.writeLock().lock();
      if (this.checkLevel == CheckLevel.DISABLE
          && checkLevel != CheckLevel.DISABLE
          && (!disallowList.isEmpty() || !disallowListPrefix.isEmpty())) {
        checkRegistrationOpen();
      }
      this.checkLevel = checkLevel;
      clearCheckerCache();
    } finally {
      lock.writeLock().unlock();
    }
  }

  @Override
  public boolean checkType(TypeResolver resolver, String className) {
    try {
      lock.readLock().lock();
      return check(className);
    } finally {
      lock.readLock().unlock();
    }
  }

  private boolean check(String className) {
    if (checkLevel == CheckLevel.DISABLE) {
      return true;
    }
    boolean disallowed =
        containsPrefix(disallowList, disallowListPrefix, className)
            || DisallowedList.contains(className);
    boolean allowed =
        containsPrefix(allowList, allowListPrefix, className)
            || DefaultJdkClassAllowList.contains(className);
    if (className.startsWith("[")) {
      Tuple2<String, Integer> componentInfo = TypeUtils.getArrayComponentInfo(className);
      String componentName = componentInfo.f0;
      if (componentName != null) {
        disallowed |=
            containsPrefix(disallowList, disallowListPrefix, componentName)
                || DisallowedList.contains(componentName);
        allowed |=
            containsPrefix(allowList, allowListPrefix, componentName)
                || DefaultJdkClassAllowList.contains(componentName);
      }
    }
    switch (checkLevel) {
      case WARN:
        if (disallowed) {
          throw new InsecureException(
              String.format(
                  "Class %s is forbidden for serialization or deserialization.", className));
        }
        if (!allowed) {
          LOG.warnOnce(
              "Class {} not in allow list, please check whether objects of this class "
                  + "are allowed for serialization or deserialization.",
              className);
        }
        return true;
      case STRICT:
        if (disallowed) {
          throw new InsecureException(
              String.format(
                  "Class %s is forbidden for serialization or deserialization.", className));
        }
        if (!allowed) {
          throw new InsecureException(
              String.format(
                  "Class %s isn't in the allow list for serialization or deserialization. If this "
                      + "class is allowed, add it with AllowListChecker#allowClass",
                  className));
        }
        return true;
      default:
        throw new UnsupportedOperationException("Unsupported check level " + checkLevel);
    }
  }

  static boolean containsPrefix(Set<String> set, Set<String> prefixSet, String className) {
    if (set.contains(className)) {
      return true;
    }
    for (String prefix : prefixSet) {
      if (className.startsWith(prefix)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Add class to allow list.
   *
   * @param classNameOrPrefix class name or name prefix ends with *.
   */
  public void allowClass(String classNameOrPrefix) {
    try {
      lock.writeLock().lock();
      allow(classNameOrPrefix);
    } finally {
      lock.writeLock().unlock();
    }
  }

  /**
   * Add classes to allow list.
   *
   * @param classNamesOrPrefixes class names or name prefixes ends with *.
   */
  public void allowClasses(Collection<String> classNamesOrPrefixes) {
    try {
      lock.writeLock().lock();
      for (String namesOrPrefix : classNamesOrPrefixes) {
        allow(namesOrPrefix);
      }
    } finally {
      lock.writeLock().unlock();
    }
  }

  private void allow(String classNameOrPrefix) {
    if (classNameOrPrefix.endsWith("*")) {
      allowListPrefix.add(classNameOrPrefix.substring(0, classNameOrPrefix.length() - 1));
    } else {
      allowList.add(classNameOrPrefix);
    }
  }

  /**
   * Add a class to the disallow list during registration setup.
   *
   * @param classNameOrPrefix class name or class name prefix ends with *.
   */
  public void disallowClass(String classNameOrPrefix) {
    try {
      lock.writeLock().lock();
      checkRegistrationOpen();
      disallow(classNameOrPrefix);
      clearCheckerCache();
    } finally {
      lock.writeLock().unlock();
    }
  }

  /**
   * Add classes to the disallow list during registration setup.
   *
   * @param classNamesOrPrefixes class names or name prefixes ends with *.
   */
  public void disallowClasses(Collection<String> classNamesOrPrefixes) {
    try {
      lock.writeLock().lock();
      checkRegistrationOpen();
      for (String classNameOrPrefix : classNamesOrPrefixes) {
        disallow(classNameOrPrefix);
      }
      clearCheckerCache();
    } finally {
      lock.writeLock().unlock();
    }
  }

  private void disallow(String classNameOrPrefix) {
    if (classNameOrPrefix.endsWith("*")) {
      String prefix = classNameOrPrefix.substring(0, classNameOrPrefix.length() - 1);
      disallowListPrefix.add(prefix);
    } else {
      disallowList.add(classNameOrPrefix);
    }
  }

  void addListener(TypeResolver resolver) {
    try {
      lock.writeLock().lock();
      if ((!disallowList.isEmpty() || !disallowListPrefix.isEmpty())
          && resolver.isRegistrationFinished()) {
        throw new IllegalStateException(
            "A checker with disallow entries cannot be installed after registration.");
      }
      listeners.put(resolver, true);
    } finally {
      lock.writeLock().unlock();
    }
  }

  void removeListener(TypeResolver resolver) {
    try {
      lock.writeLock().lock();
      listeners.remove(resolver);
    } finally {
      lock.writeLock().unlock();
    }
  }

  private void checkRegistrationOpen() {
    for (TypeResolver resolver : listeners.keySet()) {
      if (resolver.isRegistrationFinished()) {
        throw new IllegalStateException("Classes cannot be disallowed after registration.");
      }
    }
  }

  private void clearCheckerCache() {
    for (TypeResolver resolver : listeners.keySet()) {
      resolver.clearCheckerCache();
    }
  }
}
