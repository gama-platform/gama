/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.fory.serializer.collection;

import java.util.Map;
import org.apache.fory.context.CopyContext;
import org.apache.fory.context.WriteContext;
import org.apache.fory.resolver.TypeResolver;

/** Base serializer for all java maps. */
@SuppressWarnings({"unchecked", "rawtypes"})
public class MapSerializer<T extends Map> extends MapLikeSerializer<T> {
  public MapSerializer(TypeResolver typeResolver, Class<T> cls) {
    super(typeResolver, cls);
  }

  public MapSerializer(TypeResolver typeResolver, Class<T> cls, boolean supportCodegenHook) {
    super(typeResolver, cls, supportCodegenHook);
  }

  public MapSerializer(
      TypeResolver typeResolver, Class<T> cls, boolean supportCodegenHook, boolean immutable) {
    super(typeResolver, cls, supportCodegenHook, immutable);
  }

  protected MapSerializer(
      TypeResolver typeResolver, Class<T> cls, boolean supportCodegenHook, int ownerBytes) {
    super(typeResolver, cls, supportCodegenHook, false, ownerBytes);
  }

  protected MapSerializer(
      TypeResolver typeResolver,
      Class<T> cls,
      boolean supportCodegenHook,
      boolean immutable,
      int ownerBytes) {
    super(typeResolver, cls, supportCodegenHook, immutable, ownerBytes);
  }

  @Override
  public Map onMapWrite(WriteContext writeContext, T value) {
    writeContext.getBuffer().writeVarUInt32Small7(value.size());
    return value;
  }

  @Override
  public T copy(CopyContext copyContext, T originMap) {
    if (isImmutable()) {
      return originMap;
    }
    Map newMap = newMap(copyContext, originMap);
    copyContext.reference(originMap, newMap);
    copyEntry(copyContext, originMap, newMap);
    return onMapCopy(newMap);
  }

  @Override
  public T onMapCopy(Map map) {
    return (T) map;
  }

  @Override
  public T onMapRead(Map map) {
    return (T) map;
  }
}
