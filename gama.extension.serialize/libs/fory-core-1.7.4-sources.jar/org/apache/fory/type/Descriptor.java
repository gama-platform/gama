/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.fory.type;

import static org.apache.fory.util.Preconditions.checkArgument;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.fory.annotation.BFloat16Type;
import org.apache.fory.annotation.Expose;
import org.apache.fory.annotation.Float16Type;
import org.apache.fory.annotation.ForyField;
import org.apache.fory.annotation.Ignore;
import org.apache.fory.annotation.Int32Type;
import org.apache.fory.annotation.Int64Type;
import org.apache.fory.annotation.Int8Type;
import org.apache.fory.annotation.Internal;
import org.apache.fory.annotation.Ref;
import org.apache.fory.annotation.UInt16Type;
import org.apache.fory.annotation.UInt32Type;
import org.apache.fory.annotation.UInt64Type;
import org.apache.fory.annotation.UInt8Type;
import org.apache.fory.collection.Cache;
import org.apache.fory.collection.CacheBuilder;
import org.apache.fory.collection.ClassValueCache;
import org.apache.fory.collection.Collections;
import org.apache.fory.collection.Tuple2;
import org.apache.fory.meta.TypeExtMeta;
import org.apache.fory.reflect.TypeRef;
import org.apache.fory.reflect.TypeUseMetadata;
import org.apache.fory.serializer.converter.FieldConverter;
import org.apache.fory.util.ExceptionUtils;
import org.apache.fory.util.StringUtils;
import org.apache.fory.util.record.RecordComponent;
import org.apache.fory.util.record.RecordUtils;

/**
 * Build descriptors for a class.
 *
 * @see Ignore
 */
public class Descriptor {
  private static Cache<
          Class<?>, Tuple2<SortedMap<Member, Descriptor>, SortedMap<Member, Descriptor>>>
      descCache = CacheBuilder.newBuilder().weakKeys().softValues().concurrencyLevel(64).build();
  private static final Map<Class<?>, AtomicBoolean> flags = Collections.newClassKeyCacheMap();

  @Internal
  public static void clearDescriptorCache() {
    descCache.cleanUp();
    descCache = CacheBuilder.newBuilder().weakKeys().softValues().concurrencyLevel(64).build();
  }

  // All fields should not be mutable except as lazy load,
  // because Descriptor is cached in `descCache`.
  // And mutable fields may make some serializer read wrong field
  // value such as `typeName`.
  private TypeRef<?> typeRef;
  private Class<?> type;
  private final String typeName;
  private final String name;
  private String snakeCaseName;
  private final int modifier;
  private final String declaringClass;
  private final Field field;
  private final Method readMethod;
  private final Method writeMethod;
  private final ForyField foryField;
  private final boolean hasForyField;
  private final int foryFieldId;
  private final ForyField.Dynamic dynamic;
  private final Annotation typeAnnotation;
  private final boolean arrayType;
  private boolean nullable;
  // Ref metadata needs a presence bit because @Ref(enable = false) must override native
  // type-based defaults, while unrelated scalar/nullability metadata must not.
  private final boolean hasTrackingRefMetadata;
  private final boolean trackingRef;
  private FieldConverter<?> fieldConverter;

  /**
   * Type tree emitted by static generated serializers without exposing TypeRef in generated code.
   */
  @Internal
  public static final class GeneratedType {
    private final Class<?> rawType;
    private final TypeExtMeta typeExtMeta;
    private final List<GeneratedType> typeArguments;
    private final GeneratedType componentType;
    private final GeneratedType ownerType;

    private GeneratedType(
        Class<?> rawType,
        TypeExtMeta typeExtMeta,
        List<GeneratedType> typeArguments,
        GeneratedType componentType,
        GeneratedType ownerType) {
      this.rawType = Objects.requireNonNull(rawType);
      this.typeExtMeta = typeExtMeta;
      this.typeArguments =
          typeArguments == null
              ? java.util.Collections.emptyList()
              : java.util.Collections.unmodifiableList(new ArrayList<>(typeArguments));
      this.componentType = componentType;
      this.ownerType = ownerType;
    }
  }

  @Internal
  public static GeneratedType generatedType(Class<?> rawType) {
    return new GeneratedType(rawType, null, null, null, null);
  }

  @Internal
  public static GeneratedType generatedType(
      Class<?> rawType,
      TypeExtMeta typeExtMeta,
      List<GeneratedType> typeArguments,
      GeneratedType componentType) {
    return new GeneratedType(rawType, typeExtMeta, typeArguments, componentType, null);
  }

  @Internal
  public static GeneratedType generatedType(
      Class<?> rawType,
      TypeExtMeta typeExtMeta,
      List<GeneratedType> typeArguments,
      GeneratedType componentType,
      GeneratedType ownerType) {
    return new GeneratedType(rawType, typeExtMeta, typeArguments, componentType, ownerType);
  }

  private static TypeRef<?> toTypeRef(GeneratedType generatedType) {
    Objects.requireNonNull(generatedType);
    List<TypeRef<?>> typeArguments = null;
    if (!generatedType.typeArguments.isEmpty()) {
      typeArguments = new ArrayList<>(generatedType.typeArguments.size());
      for (GeneratedType typeArgument : generatedType.typeArguments) {
        typeArguments.add(toTypeRef(typeArgument));
      }
    }
    TypeRef<?> componentType =
        generatedType.componentType == null ? null : toTypeRef(generatedType.componentType);
    TypeRef<?> ownerType =
        generatedType.ownerType == null ? null : toTypeRef(generatedType.ownerType);
    if (generatedType.typeExtMeta == null
        && typeArguments == null
        && componentType == null
        && ownerType == null) {
      return TypeRef.of(generatedType.rawType);
    }
    if (typeArguments != null || ownerType != null) {
      return TypeRef.ofDeclaredTypeArguments(
          generatedType.rawType,
          generatedType.typeExtMeta,
          typeArguments == null ? java.util.Collections.emptyList() : typeArguments,
          componentType,
          ownerType);
    }
    return TypeRef.of(
        generatedType.rawType, generatedType.typeExtMeta, typeArguments, componentType);
  }

  public Descriptor(Field field, TypeRef<?> typeRef, Method readMethod, Method writeMethod) {
    this(field, typeRef, readMethod, writeMethod, null);
  }

  public Descriptor(
      Field field, TypeRef<?> typeRef, Method readMethod, Method writeMethod, boolean nullable) {
    this(field, typeRef, readMethod, writeMethod, Boolean.valueOf(nullable));
  }

  private Descriptor(
      Field field,
      TypeRef<?> typeRef,
      Method readMethod,
      Method writeMethod,
      Boolean nullableOverride) {
    this.field = field;
    // Use typeRef.getType().getTypeName() to include generic type info (e.g., Collection<Object>)
    // This ensures consistent typeName between serialization and deserialization.
    // For raw collections/maps, typeRef will have Object as element type.
    this.typeName = typeRef.getType().getTypeName();
    this.name = field.getName();
    this.modifier = field.getModifiers();
    this.declaringClass = field.getDeclaringClass().getName();
    this.readMethod = readMethod;
    this.writeMethod = writeMethod;
    this.typeRef = typeRef;
    this.foryField = this.field.getAnnotation(ForyField.class);
    this.hasForyField = foryField != null;
    this.foryFieldId = resolveForyFieldId(foryField, name);
    this.dynamic = hasForyField ? foryField.dynamic() : ForyField.Dynamic.AUTO;
    typeAnnotation = getAnnotation(field);
    arrayType = TypeAnnotationUtils.isArrayType(field);
    this.nullable =
        nullableOverride == null
            ? resolveNullable(typeRef, !hasForyField, field, null, readMethod)
            : nullableOverride;
    this.hasTrackingRefMetadata = resolveHasTrackingRefMetadata(typeRef, field, readMethod);
    this.trackingRef = resolveTrackingRef(typeRef, field, readMethod);
  }

  public Descriptor(
      GeneratedType generatedType,
      String typeName,
      String name,
      int modifier,
      String declaringClass,
      boolean hasForyField,
      int foryFieldId,
      boolean nullable,
      boolean trackingRef,
      ForyField.Dynamic dynamic,
      boolean arrayType) {
    this(
        generatedType,
        typeName,
        name,
        modifier,
        declaringClass,
        hasForyField,
        foryFieldId,
        nullable,
        trackingRef,
        trackingRef,
        dynamic,
        arrayType);
  }

  public Descriptor(
      GeneratedType generatedType,
      String typeName,
      String name,
      int modifier,
      String declaringClass,
      boolean hasForyField,
      int foryFieldId,
      boolean nullable,
      boolean trackingRef,
      boolean hasTrackingRefMetadata,
      ForyField.Dynamic dynamic,
      boolean arrayType) {
    this(
        toTypeRef(generatedType),
        typeName,
        name,
        modifier,
        declaringClass,
        hasForyField,
        foryFieldId,
        nullable,
        trackingRef,
        hasTrackingRefMetadata,
        dynamic,
        arrayType);
  }

  public Descriptor(
      TypeRef<?> typeRef,
      String typeName,
      String name,
      int modifier,
      String declaringClass,
      boolean trackingRef,
      boolean nullable) {
    this.field = null;
    this.typeName = typeName;
    this.name = name;
    this.modifier = modifier;
    this.declaringClass = declaringClass;
    this.typeRef = typeRef;
    this.readMethod = null;
    this.writeMethod = null;
    this.foryField = null;
    this.hasForyField = false;
    this.foryFieldId = -1;
    this.dynamic = ForyField.Dynamic.AUTO;
    typeAnnotation = null;
    arrayType = false;
    this.nullable = nullable;
    this.hasTrackingRefMetadata = true;
    this.trackingRef = trackingRef;
  }

  public Descriptor(
      TypeRef<?> typeRef,
      String typeName,
      String name,
      int modifier,
      String declaringClass,
      boolean hasForyField,
      int foryFieldId,
      boolean nullable,
      boolean trackingRef,
      ForyField.Dynamic dynamic) {
    this(
        typeRef,
        typeName,
        name,
        modifier,
        declaringClass,
        hasForyField,
        foryFieldId,
        nullable,
        trackingRef,
        dynamic,
        false);
  }

  public Descriptor(
      TypeRef<?> typeRef,
      String typeName,
      String name,
      int modifier,
      String declaringClass,
      boolean hasForyField,
      int foryFieldId,
      boolean nullable,
      boolean trackingRef,
      ForyField.Dynamic dynamic,
      boolean arrayType) {
    this(
        typeRef,
        typeName,
        name,
        modifier,
        declaringClass,
        hasForyField,
        foryFieldId,
        nullable,
        trackingRef,
        true,
        dynamic,
        arrayType);
  }

  public Descriptor(
      TypeRef<?> typeRef,
      String typeName,
      String name,
      int modifier,
      String declaringClass,
      boolean hasForyField,
      int foryFieldId,
      boolean nullable,
      boolean trackingRef,
      boolean hasTrackingRefMetadata,
      ForyField.Dynamic dynamic,
      boolean arrayType) {
    this.field = null;
    this.typeName = typeName;
    this.name = name;
    this.modifier = modifier;
    this.declaringClass = declaringClass;
    this.typeRef = typeRef;
    this.readMethod = null;
    this.writeMethod = null;
    this.foryField = null;
    this.hasForyField = hasForyField;
    if (hasForyField && (foryFieldId < -1 || foryFieldId > ForyField.MAX_ID)) {
      throw new IllegalArgumentException(
          "@ForyField id must be -1 (no tag ID) or in [0, 2^29) for field " + name);
    }
    this.foryFieldId = hasForyField ? foryFieldId : -1;
    this.dynamic = hasForyField ? Objects.requireNonNull(dynamic) : ForyField.Dynamic.AUTO;
    typeAnnotation = null;
    this.arrayType = arrayType;
    if (typeRef.isPrimitive()) {
      this.nullable = false;
    } else {
      this.nullable = nullable;
    }
    this.hasTrackingRefMetadata = hasTrackingRefMetadata;
    this.trackingRef = trackingRef;
  }

  private Descriptor(Field field, Method readMethod) {
    this(field, readMethod, TypeUtils.getFieldTypeRef(field), null);
  }

  private Descriptor(
      Field field, Method readMethod, TypeRef<?> typeRef, RecordComponent recordComponent) {
    this.field = field;
    // Compute typeRef from field's generic type to include generic info.
    this.typeRef = typeRef;
    // Use typeRef.getType().getTypeName() to include generic type info (e.g., Collection<Object>)
    // This ensures consistent typeName between serialization and deserialization.
    this.typeName = typeRef.getType().getTypeName();
    this.name = field.getName();
    this.modifier = field.getModifiers();
    this.declaringClass = field.getDeclaringClass().getName();
    this.readMethod = readMethod;
    this.writeMethod = null;
    this.foryField = this.field.getAnnotation(ForyField.class);
    this.hasForyField = foryField != null;
    this.foryFieldId = resolveForyFieldId(foryField, name);
    this.dynamic = hasForyField ? foryField.dynamic() : ForyField.Dynamic.AUTO;
    typeAnnotation = getAnnotation(field);
    arrayType = TypeAnnotationUtils.isArrayType(field);
    this.nullable = resolveNullable(typeRef, !hasForyField, field, recordComponent, readMethod);
    this.hasTrackingRefMetadata = resolveHasTrackingRefMetadata(typeRef, field, readMethod);
    this.trackingRef = resolveTrackingRef(typeRef, field, readMethod);
  }

  private Descriptor(Method readMethod) {
    this.field = null;
    // Compute typeRef first to include generic info
    this.typeRef = TypeUtils.getMethodReturnTypeRef(readMethod);
    // Use typeRef.getType().getTypeName() for consistent type name with generics
    this.typeName = typeRef.getType().getTypeName();
    this.name = readMethod.getName();
    this.modifier = readMethod.getModifiers();
    this.declaringClass = readMethod.getDeclaringClass().getName();
    this.readMethod = readMethod;
    this.writeMethod = null;
    this.foryField = readMethod.getAnnotation(ForyField.class);
    this.hasForyField = foryField != null;
    this.foryFieldId = resolveForyFieldId(foryField, name);
    this.dynamic = hasForyField ? foryField.dynamic() : ForyField.Dynamic.AUTO;
    typeAnnotation = TypeUtils.getMethodReturnTypeUseAnnotation(readMethod, readMethod.getName());
    arrayType = TypeAnnotationUtils.isArrayType(readMethod);
    this.nullable = resolveNullable(typeRef, !hasForyField, null, null, readMethod);
    this.hasTrackingRefMetadata = resolveHasTrackingRefMetadata(typeRef, null, readMethod);
    this.trackingRef = resolveTrackingRef(typeRef, null, readMethod);
  }

  public Descriptor(DescriptorBuilder builder) {
    this.typeRef = builder.typeRef;
    this.typeName = builder.typeName;
    this.name = builder.name;
    this.modifier = builder.modifier;
    this.declaringClass = builder.declaringClass;
    this.field = builder.field;
    this.readMethod = builder.readMethod;
    this.writeMethod = builder.writeMethod;
    this.hasTrackingRefMetadata = builder.hasTrackingRefMetadata;
    this.trackingRef = builder.trackingRef;
    this.foryField =
        builder.foryField != null
            ? builder.foryField
            : (this.field == null ? null : this.field.getAnnotation(ForyField.class));
    if (builder.hasForyField) {
      if (builder.foryFieldId < -1 || builder.foryFieldId > ForyField.MAX_ID) {
        throw new IllegalArgumentException(
            "@ForyField id must be -1 (no tag ID) or in [0, 2^29) for field " + name);
      }
      this.hasForyField = true;
      this.foryFieldId = builder.foryFieldId;
      this.dynamic = Objects.requireNonNull(builder.dynamic);
    } else {
      this.hasForyField = foryField != null;
      this.foryFieldId = resolveForyFieldId(foryField, name);
      this.dynamic = hasForyField ? foryField.dynamic() : ForyField.Dynamic.AUTO;
    }
    typeAnnotation = field == null ? null : getAnnotation(field);
    arrayType =
        builder.arrayType
            || TypeAnnotationUtils.isArrayType(field)
            || TypeAnnotationUtils.isArrayType(readMethod);
    // Use builder.nullable directly - this is set by DescriptorBuilder.nullable()
    // and should be respected, especially for xlang compatible mode where remote
    // TypeDef's nullable flag may differ from local field's nullable
    this.nullable = builder.nullable;
    this.type = builder.type;
    this.fieldConverter = builder.fieldConverter;
  }

  public DescriptorBuilder copyBuilder() {
    return new DescriptorBuilder(this);
  }

  private static int resolveForyFieldId(ForyField foryField, String fieldName) {
    if (foryField == null) {
      return -1;
    }
    int id = foryField.id();
    if (id < -1 || id > ForyField.MAX_ID) {
      throw new IllegalArgumentException(
          "@ForyField id must be -1 (no tag ID) or in [0, 2^29) for field " + fieldName);
    }
    return id;
  }

  private static boolean resolveHasTrackingRefMetadata(
      TypeRef<?> typeRef, Field field, Method readMethod) {
    if (field != null && field.getAnnotation(Ref.class) != null) {
      return true;
    }
    if (getTypeUseRef(field, readMethod) != null) {
      return true;
    }
    TypeExtMeta typeExtMeta = typeRef.getTypeExtMeta();
    return typeExtMeta != null && typeExtMeta.trackingRef();
  }

  private static boolean resolveTrackingRef(TypeRef<?> typeRef, Field field, Method readMethod) {
    Ref ref = field == null ? null : field.getAnnotation(Ref.class);
    if (ref != null) {
      return ref.enable();
    }
    ref = getTypeUseRef(field, readMethod);
    if (ref != null) {
      return ref.enable();
    }
    TypeExtMeta typeExtMeta = typeRef.getTypeExtMeta();
    return typeExtMeta != null && typeExtMeta.trackingRef();
  }

  private static Ref getTypeUseRef(Field field, Method readMethod) {
    Object typeUse =
        field != null
            ? TypeUseMetadata.fieldTypeUse(field)
            : (readMethod == null ? null : TypeUseMetadata.methodReturnTypeUse(readMethod));
    return typeUse == null ? null : TypeUseMetadata.typeUseAnnotation(typeUse, Ref.class);
  }

  private static boolean resolveNullable(
      TypeRef<?> typeRef,
      boolean defaultNullable,
      Field field,
      RecordComponent recordComponent,
      Method readMethod) {
    return TypeUtils.isNullable(typeRef, defaultNullable, field, recordComponent, readMethod);
  }

  public Descriptor copy(Method readMethod, Method writeMethod) {
    return new DescriptorBuilder(this).readMethod(readMethod).writeMethod(writeMethod).build();
  }

  public Descriptor copyWithTypeName(String typeName) {
    return new DescriptorBuilder(this).typeName(typeName).build();
  }

  public Field getField() {
    return field;
  }

  public String getName() {
    return name;
  }

  public Class<?> getType() {
    return type;
  }

  public boolean isNullable() {
    return nullable;
  }

  public boolean isTrackingRef() {
    return trackingRef;
  }

  public boolean hasTrackingRefMetadata() {
    return hasTrackingRefMetadata;
  }

  public int getModifier() {
    return modifier;
  }

  public String getSnakeCaseName() {
    if (snakeCaseName == null) {
      snakeCaseName = StringUtils.lowerCamelToLowerUnderscore(name);
    }
    return snakeCaseName;
  }

  public int getModifiers() {
    return modifier;
  }

  public boolean isFinalField() {
    return Modifier.isFinal(modifier);
  }

  public String getDeclaringClass() {
    return declaringClass;
  }

  public Method getReadMethod() {
    return readMethod;
  }

  public Method getWriteMethod() {
    return writeMethod;
  }

  public String getTypeName() {
    return typeName;
  }

  public ForyField getForyField() {
    return foryField;
  }

  public boolean hasForyField() {
    return hasForyField;
  }

  public boolean hasForyFieldId() {
    return hasForyField && foryFieldId >= 0;
  }

  public int getForyFieldId() {
    return foryFieldId;
  }

  /**
   * Returns the morphic setting for this field.
   *
   * @return the morphic setting from @ForyField annotation, or AUTO if not specified
   */
  public ForyField.Dynamic getMorphic() {
    return dynamic;
  }

  public Annotation getTypeAnnotation() {
    return typeAnnotation;
  }

  public boolean isArrayType() {
    return arrayType;
  }

  /** Try not use {@link TypeRef#getRawType()} since it's expensive. */
  public Class<?> getRawType() {
    Class<?> type = this.type;
    if (type == null) {
      return this.type = TypeUtils.getRawType(getTypeRef());
    }
    return Objects.requireNonNull(type);
  }

  public TypeRef<?> getTypeRef() {
    TypeRef<?> typeRef = this.typeRef;
    if (typeRef == null && field != null) {
      this.typeRef = typeRef = TypeUtils.getFieldTypeRef(field);
    }
    return typeRef;
  }

  public FieldConverter<?> getFieldConverter() {
    return fieldConverter;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Descriptor{");
    sb.append("name=").append(name);
    sb.append(", typeName=").append(typeName);
    sb.append(", modifier=").append(modifier);
    if (field != null) {
      sb.append(", declaringClass=").append(field.getDeclaringClass().getSimpleName());
    }
    if (readMethod != null) {
      sb.append(", readMethod=").append(readMethod);
    }
    if (writeMethod != null) {
      sb.append(", writeMethod=").append(writeMethod);
    }
    if (typeRef != null) {
      sb.append(", typeRef=").append(typeRef);
    }
    sb.append(", foryField=").append(foryField);
    sb.append(", trackingRef=").append(trackingRef);
    sb.append(", foryFieldConverter=").append(fieldConverter);
    sb.append(", nullable=").append(nullable);
    sb.append('}');
    return sb.toString();
  }

  /**
   * Returns descriptors non-transient/non-static fields of class. If super class and sub class have
   * same field, use subclass field.
   */
  public static List<Descriptor> getDescriptors(Class<?> clz) {
    // TODO(chaokunyang) add cache by weak class key, see java.io.ObjectStreamClass.WeakClassKey.
    SortedMap<Member, Descriptor> allDescriptorsMap = getAllDescriptorsMap(clz);
    Map<String, List<Member>> duplicateNameFields = getDuplicateNames(allDescriptorsMap);
    checkArgument(
        duplicateNameFields.isEmpty(), "%s has duplicate fields %s", clz, duplicateNameFields);
    return new ArrayList<>(allDescriptorsMap.values());
  }

  /**
   * Returns descriptors map non-transient/non-static fields of class. Super class and sub class are
   * not allowed to have duplicate name field.
   */
  public static SortedMap<String, Descriptor> getDescriptorsMap(Class<?> clz) {
    SortedMap<Member, Descriptor> allDescriptorsMap = getAllDescriptorsMap(clz);
    Map<String, List<Member>> duplicateNameFields = getDuplicateNames(allDescriptorsMap);
    checkArgument(
        duplicateNameFields.isEmpty(), "%s has duplicate fields %s", clz, duplicateNameFields);
    TreeMap<String, Descriptor> map = new TreeMap<>();
    allDescriptorsMap.forEach((k, v) -> map.put(k.getName(), v));
    return map;
  }

  private static final ClassValueCache<Map<String, List<Member>>> sortedDuplicatedMembers =
      ClassValueCache.newClassKeyCache(32);

  public static Map<String, List<Member>> getDuplicateNames(
      SortedMap<Member, Descriptor> allDescriptorsMap) {
    Map<String, List<Member>> duplicateNames = new HashMap<>();
    for (Member member : allDescriptorsMap.keySet()) {
      duplicateNames.compute(
          member.getName(),
          (memberName, members) -> {
            if (members == null) {
              members = new ArrayList<>();
            }
            members.add(member);
            return members;
          });
    }
    Map<String, List<Member>> map = new HashMap<>();
    for (Map.Entry<String, List<Member>> e : duplicateNames.entrySet()) {
      if (Objects.requireNonNull(e.getValue()).size() > 1) {
        map.put(e.getKey(), e.getValue());
      }
    }
    return map;
  }

  public static Map<String, List<Member>> getSortedDuplicatedMembers(Class<?> cls) {
    return sortedDuplicatedMembers.get(cls, () -> sortedDuplicatedMembers(cls));
  }

  private static Map<String, List<Member>> sortedDuplicatedMembers(Class<?> type) {
    SortedMap<Member, Descriptor> allFields = Descriptor.getAllDescriptorsMap(type);
    Map<String, List<Member>> duplicated = Descriptor.getDuplicateNames(allFields);
    Map<String, List<Member>> map = new HashMap<>();
    for (Map.Entry<String, List<Member>> e : duplicated.entrySet()) {
      e.getValue()
          .sort(
              (f1, f2) -> {
                if (f1.getDeclaringClass() == f2.getDeclaringClass()) {
                  return 0;
                } else {
                  return f1.getDeclaringClass().isAssignableFrom(f2.getDeclaringClass()) ? -1 : 1;
                }
              });
      if (map.put(e.getKey(), e.getValue()) != null) {
        throw new IllegalStateException("Duplicate key");
      }
    }
    return map;
  }

  /**
   * Return all non-transient/non-static fields of {@code clz} in a deterministic order with field
   * name first and declaring class second. Super class and sub class can have same name field.
   */
  public static Set<Field> getFields(Class<?> clz) {
    Set<Field> fields = new TreeSet<>(memberComparator);
    for (Member member : getAllDescriptorsMap(clz).keySet()) {
      if (member instanceof Field) {
        fields.add((Field) member);
      }
    }
    return fields;
  }

  /**
   * Returns descriptors map non-transient/non-static fields of class in a deterministic order with
   * field name first and declaring class second. Super class and subclass can have same names
   * field.
   */
  public static SortedMap<Member, Descriptor> getAllDescriptorsMap(Class<?> clz) {
    return getAllDescriptorsMap(clz, true);
  }

  private static final Comparator<Member> memberComparator =
      ((Member m1, Member m2) -> {
        int compare = m1.getName().compareTo(m2.getName());
        if (compare == 0) { // class and super classes have same named field
          return m1.getDeclaringClass().getName().compareTo(m2.getDeclaringClass().getName());
        } else {
          return compare;
        }
      });

  public static SortedMap<Member, Descriptor> getAllDescriptorsMap(
      Class<?> clz, boolean searchParent) {
    try {
      Tuple2<SortedMap<Member, Descriptor>, SortedMap<Member, Descriptor>> tuple2 =
          descCache.get(clz, () -> createAllDescriptorsMap(clz));
      if (searchParent) {
        return tuple2.f0;
      } else {
        return tuple2.f1;
      }
    } catch (ExecutionException e) {
      Throwable cause = e.getCause();
      if (cause instanceof RuntimeException) {
        throw (RuntimeException) cause;
      }
      throw new RuntimeException(cause);
    }
  }

  private static Tuple2<SortedMap<Member, Descriptor>, SortedMap<Member, Descriptor>>
      createAllDescriptorsMap(Class<?> clz) {
    // use TreeMap to sort to fix field order
    TreeMap<Member, Descriptor> descriptorMap = new TreeMap<>(memberComparator);
    TreeMap<Member, Descriptor> currentDescriptorMap = new TreeMap<>(memberComparator);
    Class<?> clazz = clz;
    // TODO(chaokunyang) use fory compiler thread pool
    ExecutorService compilationService = ForkJoinPool.commonPool();
    if (RecordUtils.isRecord(clz)) {
      RecordComponent[] components = RecordUtils.getRecordComponents(clazz);
      assert components != null;
      try {
        for (RecordComponent component : components) {
          Field field = clz.getDeclaredField(component.getName());
          descriptorMap.put(
              field,
              new Descriptor(
                  field,
                  component.getAccessor(),
                  TypeUtils.getRecordComponentTypeRef(component),
                  component));
        }
      } catch (NoSuchFieldException e) {
        // impossible
        ExceptionUtils.throwException(e);
      }
      currentDescriptorMap = new TreeMap<>(descriptorMap);
      return Tuple2.of(descriptorMap, currentDescriptorMap);
    }
    if (clazz.isInterface()) {
      for (Method method : clazz.getMethods()) {
        if (method.getParameterCount() == 0
            && method.getReturnType() != void.class
            && !Modifier.isStatic(method.getModifiers())
            && !method.isAnnotationPresent(Ignore.class)) {
          descriptorMap.put(method, new Descriptor(method));
        }
      }

      currentDescriptorMap = new TreeMap<>(descriptorMap);
      return Tuple2.of(descriptorMap, currentDescriptorMap);
    }
    do {
      Field[] fields = clazz.getDeclaredFields();
      boolean haveExpose = false, haveIgnore = false;
      for (Field field : fields) {
        warmField(clz, field, compilationService);
        if (field.isAnnotationPresent(Expose.class)) {
          haveExpose = true;
        }
        if (field.isAnnotationPresent(Ignore.class)) {
          haveIgnore = true;
        }
        if (haveExpose && haveIgnore) {
          throw new RuntimeException(
              "Fields of a Class are not allowed to have both the Ignore and Expose annotations simultaneously.");
        }
      }
      for (Field field : fields) {
        int modifiers = field.getModifiers();
        // final and non-private field validation left to {@link isBean(clz)}
        if (!Modifier.isTransient(modifiers) && !Modifier.isStatic(modifiers)) {
          if (haveExpose) {
            if (field.isAnnotationPresent(Expose.class)) {
              descriptorMap.put(field, new Descriptor(field, null));
            }
          } else {
            if (!field.isAnnotationPresent(Ignore.class)) {
              descriptorMap.put(field, new Descriptor(field, null));
            }
          }
        }
      }
      if (clazz == clz) {
        currentDescriptorMap = new TreeMap<>(descriptorMap);
      }
      clazz = clazz.getSuperclass();
    } while (clazz != null);
    return Tuple2.of(descriptorMap, currentDescriptorMap);
  }

  /**
   * Speedup generics resolve by multi-thread since {@link Field#getGenericType()} is slow and
   * nested Descriptor is slow in single thread.
   */
  static void warmField(Class<?> context, Field field, ExecutorService compilationService) {
    Class<?> fieldRawType = field.getType();
    if (fieldRawType.isPrimitive()
        || fieldRawType == String.class
        || fieldRawType == Object.class) {
      return;
    }
    if (TypeUtils.isBoxed(fieldRawType)) {
      return;
    }
    if (fieldRawType == context) {
      // avoid duplicate build.
      return;
    }
    if (!fieldRawType.getName().startsWith("java")) {
      compilationService.submit(
          () -> {
            // use a flag to avoid blocking thread.
            AtomicBoolean flag = flags.computeIfAbsent(fieldRawType, k -> new AtomicBoolean(false));
            if (flag.compareAndSet(false, true)) {
              getAllDescriptorsMap(fieldRawType);
            }
          });
    } else if (TypeUtils.isCollection(fieldRawType) || TypeUtils.isMap(fieldRawType)) {
      // warm up generic type, sun.reflect.generics.repository.FieldRepository
      // is expensive.
      compilationService.submit(() -> warmGenericTask(TypeUtils.getFieldTypeRef(field)));
    } else if (fieldRawType.isArray()) {
      Class<?> componentType = fieldRawType.getComponentType();
      if (!componentType.isPrimitive()) {
        compilationService.submit(() -> warmGenericTask(TypeUtils.getFieldTypeRef(field)));
      }
    }
  }

  // this method should b executed in background thread pool.
  static void warmGenericTask(TypeRef<?> typeRef) {
    Class<?> rawType = TypeUtils.getRawType(typeRef);
    if (rawType.isPrimitive() || rawType == String.class || rawType == Object.class) {
      return;
    }
    if (TypeUtils.isBoxed(rawType)) {
      return;
    }
    if (!rawType.getName().startsWith("java")) {
      getAllDescriptorsMap(rawType);
    } else if (TypeUtils.isCollection(rawType)) {
      TypeRef<?> elementType = TypeUtils.getElementType(typeRef);
      warmGenericTask(elementType);
    } else if (TypeUtils.isMap(rawType)) {
      Tuple2<TypeRef<?>, TypeRef<?>> mapKeyValueType = TypeUtils.getMapKeyValueType(typeRef);
      warmGenericTask(mapKeyValueType.f0);
      warmGenericTask(mapKeyValueType.f1);
    } else if (rawType.isArray()) {
      warmGenericTask(typeRef.getComponentType());
    }
  }

  static SortedMap<Field, Descriptor> buildBeanedDescriptorsMap(
      Class<?> clz, boolean searchParent) {
    List<Field> fieldList = new ArrayList<>();
    Class<?> clazz = clz;
    Map<Tuple2<Class<?>, String>, Method> methodMap = new HashMap<>();
    do {
      Field[] fields = clazz.getDeclaredFields();
      for (Field field : fields) {
        int modifiers = field.getModifiers();
        // final and non-private field validation left to {@link isBean(clz)}
        if (!Modifier.isTransient(modifiers)
            && !Modifier.isStatic(modifiers)
            && !field.isAnnotationPresent(Ignore.class)) {
          fieldList.add(field);
        }
      }
      Arrays.stream(clazz.getDeclaredMethods())
          .filter(m -> !Modifier.isPrivate(m.getModifiers()))
          // if override, use subClass method; getter/setter method won't overload
          .forEach(m -> methodMap.put(Tuple2.of(m.getDeclaringClass(), m.getName()), m));
      clazz = clazz.getSuperclass();
    } while (clazz != null && searchParent);

    for (Class<?> anInterface : clz.getInterfaces()) {
      Method[] methods = anInterface.getDeclaredMethods();
      for (Method method : methods) {
        if (method.isDefault()) {
          methodMap.put(Tuple2.of(method.getDeclaringClass(), method.getName()), method);
        }
      }
    }

    // use TreeMap to sort to fix field order
    TreeMap<Field, Descriptor> descriptorMap = new TreeMap<>(memberComparator);
    for (Field field : fieldList) {
      Class<?> fieldDeclaringClass = field.getDeclaringClass();
      String fieldName = field.getName();
      String cap = StringUtils.capitalize(fieldName);
      Method getter;
      if ("boolean".equalsIgnoreCase(field.getType().getSimpleName())) {
        getter = methodMap.get(Tuple2.of(fieldDeclaringClass, "is" + cap));
      } else {
        getter = methodMap.get(Tuple2.of(fieldDeclaringClass, "get" + cap));
      }
      if (getter != null) {
        if (getter.getParameterCount() != 0
            || !getter
                .getGenericReturnType()
                .getTypeName()
                .equals(field.getGenericType().getTypeName())) {
          getter = null;
        }
      }
      Method setter = methodMap.get(Tuple2.of(fieldDeclaringClass, "set" + cap));
      if (setter != null) {
        if (setter.getParameterCount() != 1
            || !setter
                .getGenericParameterTypes()[0]
                .getTypeName()
                .equals(field.getGenericType().getTypeName())) {
          setter = null;
        }
      }
      TypeRef<?> fieldType = TypeUtils.getFieldTypeRef(field);
      descriptorMap.put(field, new Descriptor(field, fieldType, getter, setter));
    }
    // Don't cache descriptors using a static `WeakHashMap<Class<?>, SortedMap<Field, Descriptor>>`，
    // otherwise classes can't be gc.
    return descriptorMap;
  }

  private static final Set<Class<?>> typeAnnotationsTypes = new HashSet<>();

  static {
    typeAnnotationsTypes.add(Int32Type.class);
    typeAnnotationsTypes.add(Int64Type.class);
    typeAnnotationsTypes.add(Int8Type.class);
    typeAnnotationsTypes.add(UInt8Type.class);
    typeAnnotationsTypes.add(UInt16Type.class);
    typeAnnotationsTypes.add(UInt32Type.class);
    typeAnnotationsTypes.add(UInt64Type.class);
    typeAnnotationsTypes.add(Float16Type.class);
    typeAnnotationsTypes.add(BFloat16Type.class);
  }

  public static Annotation getAnnotation(Field field) {
    Annotation typeAnnotation = TypeUtils.getFieldTypeUseAnnotation(field, field.getName());
    if (typeAnnotation == null) {
      return getAnnotation(field.getDeclaredAnnotations(), field.getName());
    }
    return typeAnnotation;
  }

  public static Annotation getAnnotation(Annotation[] declaredAnnotations, String name) {
    Annotation typeAnnotation = null;
    for (Annotation annotation : declaredAnnotations) {
      if (typeAnnotationsTypes.contains(annotation.annotationType())) {
        if (typeAnnotation != null) {
          throw new IllegalStateException(
              String.format(
                  "Multiple type annotation %s and %s found for %s!",
                  typeAnnotation, annotation.annotationType(), name));
        }
        typeAnnotation = annotation;
      }
    }
    return typeAnnotation;
  }

  public static Class<?> getDeclareClass(List<Descriptor> descriptors) {
    Class<?> cls = Object.class;
    for (Descriptor descriptor : descriptors) {
      Field field = descriptor.getField();
      if (field == null) {
        continue;
      }
      if (cls.isAssignableFrom(field.getDeclaringClass())) {
        cls = field.getDeclaringClass();
      }
    }
    return cls;
  }
}
