/* Copyright 2009-2025 David Hadka
 *
 * This file is part of the MOEA Framework.
 *
 * The MOEA Framework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The MOEA Framework is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with the MOEA Framework.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.moeaframework.core.population;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.math3.linear.SingularMatrixException;
import org.moeaframework.core.PRNG;
import org.moeaframework.core.Settings;
import org.moeaframework.core.Solution;
import org.moeaframework.core.attribute.Niche;
import org.moeaframework.core.attribute.NicheDistance;
import org.moeaframework.core.attribute.NormalizedObjectives;
import org.moeaframework.core.attribute.Rank;
import org.moeaframework.core.comparator.DominanceComparator;
import org.moeaframework.core.comparator.RankComparator;
import org.moeaframework.util.LinearAlgebra;
import org.moeaframework.util.Vector;
import org.moeaframework.util.validate.Validate;
import org.moeaframework.util.weights.NormalBoundaryDivisions;
import org.moeaframework.util.weights.NormalBoundaryIntersectionGenerator;

/**
 * Implementation of the reference-point-based nondominated sorting method for NSGA-III.  NSGA-III includes an
 * additional parameter, the number of divisions, that controls the spacing of reference points.  For large objective
 * counts, an alternate two-layered approach was also proposed allowing the user to specify the divisions on the outer
 * and inner layer.  When using the two-layered approach, the number of outer divisions should less than the number of
 * objectives, otherwise it will generate reference points overlapping with the inner layer.  If there are {@code M}
 * objectives and {@code p} divisions, then {@code binomialCoefficient(M+p-1, p)} reference points are generated.
 * <p>
 * References:
 * <ol>
 *   <li>Deb, K. and Jain, H.  "An Evolutionary Many-Objective Optimization Algorithm Using Reference-Point-Based
 *       Nondominated Sorting Approach, Part I: Solving Problems With Box Constraints."  IEEE Transactions on
 *       Evolutionary Computation, 18(4):577-601, 2014.
 *   <li>Deb, K. and Jain, H.  "Handling Many-Objective Problems Using an Improved NSGA-II Procedure.  WCCI 2012 IEEE
 *       World Contress on Computational Intelligence, Brisbane, Australia, June 10-15, 2012.
 *   <li><a href="http://web.ntnu.edu.tw/~tcchiang/publications/nsga3cpp/nsga3cpp.htm">C++ Implementation by Tsung-Che
 *       Chiang</a>
 * </ol>
 */
public class ReferencePointNondominatedSortingPopulation extends NondominatedSortingPopulation {

	/**
	 * The number of objectives.
	 */
	private final int numberOfObjectives;

	/**
	 * The number of divisions.
	 */
	private final NormalBoundaryDivisions divisions;

	/**
	 * The ideal point, updated each iteration.
	 */
	double[] idealPoint;

	/**
	 * The list of reference points, or weights.
	 */
	private double[][] weights;

	/**
	 * Constructs an empty population that maintains the {@code rank} attribute for its solutions.
	 * 
	 * @param numberOfObjectives the number of objectives
	 * @param divisions the number of divisions
	 */
	public ReferencePointNondominatedSortingPopulation(int numberOfObjectives, NormalBoundaryDivisions divisions) {
		super();
		this.numberOfObjectives = numberOfObjectives;
		this.divisions = divisions;

		initialize();
	}

	/**
	 * Constructs a new population with the specified solutions that maintains the {@code rank} attribute for its
	 * solutions.
	 * 
	 * @param numberOfObjectives the number of objectives
	 * @param divisions the number of divisions
	 * @param comparator the dominance comparator
	 * @param iterable the solutions used to initialize this population
	 */
	public ReferencePointNondominatedSortingPopulation(int numberOfObjectives, NormalBoundaryDivisions divisions,
			DominanceComparator comparator, Iterable<? extends Solution> iterable) {
		super(comparator, iterable);
		this.numberOfObjectives = numberOfObjectives;
		this.divisions = divisions;

		initialize();
	}

	/**
	 * Constructs an empty population that maintains the {@code rank} attribute for its solutions.
	 * 
	 * @param numberOfObjectives the number of objectives
	 * @param divisions the number of divisions
	 * @param comparator the dominance comparator
	 */
	public ReferencePointNondominatedSortingPopulation(int numberOfObjectives, NormalBoundaryDivisions divisions,
			DominanceComparator comparator) {
		super(comparator);
		this.numberOfObjectives = numberOfObjectives;
		this.divisions = divisions;

		initialize();
	}

	/**
	 * Constructs a new population with the specified solutions that maintains the {@code rank} attribute for its
	 * solutions.
	 * 
	 * @param numberOfObjectives the number of objectives
	 * @param divisions the number of divisions
	 * @param iterable the solutions used to initialize this population
	 */
	public ReferencePointNondominatedSortingPopulation(int numberOfObjectives, NormalBoundaryDivisions divisions,
			Iterable<? extends Solution> iterable) {
		super(iterable);
		this.numberOfObjectives = numberOfObjectives;
		this.divisions = divisions;

		initialize();
	}
	
	/**
	 * Returns the number of divisions used to create the reference points.
	 * 
	 * @return the divisions object
	 */
	public NormalBoundaryDivisions getDivisions() {
		return divisions;
	}
	
	/**
	 * Initializes the ideal point and reference points (weights).
	 */
	private void initialize() {
		idealPoint = new double[numberOfObjectives];
		Arrays.fill(idealPoint, Double.POSITIVE_INFINITY);
		
		weights = new NormalBoundaryIntersectionGenerator(numberOfObjectives, divisions).generate()
				.toArray(double[][]::new);
	}

	/**
	 * Updates the ideal point given the solutions currently in this population.
	 */
	protected void updateIdealPoint() {
		for (Solution solution : this) {
			Validate.that("solution.getNumberOfObjectives()", solution.getNumberOfObjectives())
				.isEqualTo(numberOfObjectives);

			for (int i = 0; i < numberOfObjectives; i++) {
				idealPoint[i] = Math.min(idealPoint[i], solution.getObjective(i).getCanonicalValue());
			}
		}
	}

	/**
	 * Offsets the solutions in this population by the ideal point.  This method does not modify the objective values,
	 * instead it sets the {@link NormalizedObjectives} attribute.
	 */
	protected void translateByIdealPoint() {
		for (Solution solution : this) {
			double[] objectives = solution.getCanonicalObjectiveValues();

			for (int i = 0; i < numberOfObjectives; i++) {
				objectives[i] -= idealPoint[i];
			}

			NormalizedObjectives.setAttribute(solution, objectives);
		}
	}

	/**
	 * Normalizes the solutions in this population by the given intercepts (or scaling factors).  This method does not
	 * modify the objective values, instead it sets the {@link NormalizedObjectives} attribute.
	 * 
	 * @param intercepts the intercepts used for scaling
	 */
	protected void normalizeByIntercepts(double[] intercepts) {
		for (Solution solution : this) {
			double[] objectives = NormalizedObjectives.getAttribute(solution);

			for (int i = 0; i < solution.getNumberOfObjectives(); i++) {
				objectives[i] /= intercepts[i];
			}
		}
	}

	/**
	 * The Chebyshev achievement scalarizing function.
	 * 
	 * @param solution the normalized solution
	 * @param weights the reference point (weight vector)
	 * @return the value of the scalarizing function
	 */
	protected static double achievementScalarizingFunction(Solution solution, double[] weights) {
		double max = Double.NEGATIVE_INFINITY;
		double[] objectives = NormalizedObjectives.getAttribute(solution);

		for (int i = 0; i < solution.getNumberOfObjectives(); i++) {
			max = Math.max(max, objectives[i]/weights[i]);
		}

		return max;
	}

	/**
	 * Returns the extreme point in the given objective.  The extreme point is the point that minimizes the achievement
	 * scalarizing function using a reference point near the given objective.
	 * 
	 * The NSGA-III paper (1) does not provide any details on the scalarizing function, but an earlier paper by the
	 * authors (2) where some precursor experiments are performed does define a possible function, replicated below.
	 * 
	 * @param objective the objective index
	 * @return the extreme point in the given objective
	 */
	protected Solution findExtremePoint(int objective) {
		double eps = 0.000001;
		double[] weights = new double[numberOfObjectives];

		for (int i = 0; i < numberOfObjectives; i++) {
			if (i == objective) {
				weights[i] = 1.0;
			} else {
				weights[i] = eps;
			}
		}

		Solution result = null;
		double resultASF = Double.POSITIVE_INFINITY;

		for (int i = 0; i < size(); i++) {
			Solution solution = get(i);
			double solutionASF = achievementScalarizingFunction(solution, weights);

			if (solutionASF < resultASF) {
				result = solution;
				resultASF = solutionASF;
			}
		}

		return result;
	}

	/**
	 * Returns the extreme points for all objectives.
	 * 
	 * @return an array of extreme points, each index corresponds to each objective
	 */
	private Solution[] extremePoints() {
		Solution[] result = new Solution[numberOfObjectives];

		for (int i = 0; i < numberOfObjectives; i++) {
			result[i] = findExtremePoint(i);
		}

		return result;
	}

	/**
	 * Calculates the intercepts between the hyperplane formed by the extreme points and each axis.  The original
	 * paper (1) is unclear how to handle degenerate cases, which occurs more frequently at larger dimensions.  In
	 * this implementation, we simply use the nadir point for scaling.
	 * 
	 * @return an array of the intercept points for each objective
	 */
	protected double[] calculateIntercepts() {
		Solution[] extremePoints = extremePoints();
		boolean degenerate = false;
		double[] intercepts = new double[numberOfObjectives];

		try {
			double[] b = new double[numberOfObjectives];
			double[][] A = new double[numberOfObjectives][numberOfObjectives];
			
			for (int i = 0; i < numberOfObjectives; i++) {
				double[] objectives = NormalizedObjectives.getAttribute(extremePoints[i]);

				b[i] = 1.0;

				for (int j = 0; j < numberOfObjectives; j++) {
					A[i][j] = objectives[j];
				}
			}

			double[] result = LinearAlgebra.lsolve(A, b);

			for (int i = 0; i < numberOfObjectives; i++) {
				intercepts[i] = 1.0 / result[i];
			}
		} catch (SingularMatrixException e) {
			degenerate = true;
		}

		if (!degenerate) {
			// avoid small or negative intercepts
			for (int i = 0; i < numberOfObjectives; i++) {
				if (intercepts[i] < 0.001) {
					degenerate = true;
					break;
				}
			}
		}
		
		if (degenerate) {
			Arrays.fill(intercepts, Double.NEGATIVE_INFINITY);
			
			for (Solution solution : this) {
				for (int i = 0; i < numberOfObjectives; i++) {
					intercepts[i] = Math.max(
							Math.max(intercepts[i], Settings.EPS),
							solution.getObjective(i).getCanonicalValue());
				}
			}
		}

		return intercepts;
	}

	/**
	 * Associates each solution to the nearest reference point, returning a list-of-lists.  The outer list maps to
	 * each reference point using their index.  The inner list is an unordered collection of the solutions associated
	 * with the reference point.
	 * <p>
	 * As a side-effect, this method also sets the {@link Niche} and {@link NicheDistance} attributes.
	 * 
	 * @param population the population of solutions
	 * @return the association of solutions to reference points
	 */
	protected List<List<Solution>> associateToReferencePoint(Population population) {
		List<List<Solution>> result = new ArrayList<>();

		for (int i = 0; i < weights.length; i++) {
			result.add(new ArrayList<>());
		}

		for (Solution solution : population) {
			double[] objectives = NormalizedObjectives.getAttribute(solution);
			double minDistance = Double.POSITIVE_INFINITY;
			int minIndex = -1;

			for (int i = 0; i < weights.length; i++) {
				double distance = Vector.pointLineDistance(objectives, weights[i]);

				if (distance < minDistance) {
					minDistance = distance;
					minIndex = i;
				}
			}

			result.get(minIndex).add(solution);
			
			Niche.setAttribute(solution, minIndex);
			NicheDistance.setAttribute(solution, minDistance);
		}

		return result;
	}

	/**
	 * Returns the solution with the minimum perpendicular distance to the given reference point.
	 * 
	 * @param solutions the list of solutions being considered
	 * @param weight the reference point
	 * @return the solution nearest to the reference point
	 */
	protected Solution findSolutionWithMinimumDistance(List<Solution> solutions, double[] weight) {
		double minDistance = Double.POSITIVE_INFINITY;
		Solution minSolution = null;

		for (int i = 0; i < solutions.size(); i++) {
			double[] objectives = NormalizedObjectives.getAttribute(solutions.get(i));
			double distance = Vector.pointLineDistance(objectives, weight);
			
			if (distance < minDistance) {
				minDistance = distance;
				minSolution = solutions.get(i);
			}
		}

		return minSolution;
	}

	/**
	 * Truncates the population to the specified size using the reference-point based nondominated sorting method.
	 */
	@Override
	public void truncate(int size, Comparator<? super Solution> comparator) {
		if (size() > size) {
			// remove all solutions past the last front
			sort(new RankComparator());
			
			int maxRank = Rank.getAttribute(super.get(size-1));
			Population front = new Population();

			for (int i = 0; i < size(); i++) {
				int rank = Rank.getAttribute(get(i));
				
				if (rank > maxRank) {
					front.add(get(i));
				}
			}

			removeAll(front);
			
			// update the ideal point
			updateIdealPoint();

			// translate objectives so the ideal point is at the origin
			translateByIdealPoint();
			
			// calculate the extreme points, calculate the hyperplane defined by the extreme points, and compute the
			// intercepts
			normalizeByIntercepts(calculateIntercepts());

			// get the solutions in the last front
			front = new Population();

			for (int i = 0; i < size(); i++) {
				int rank = Rank.getAttribute(get(i));

				if (rank == maxRank) {
					front.add(get(i));
				}
			}

			removeAll(front);

			// associate each solution to a reference point
			List<List<Solution>> members = associateToReferencePoint(this);
			List<List<Solution>> potentialMembers = associateToReferencePoint(front);
			Set<Integer> excluded = new HashSet<>();
			
			// loop over niche-preservation operation until population is full
			while (size() < size) {
				// identify reference point with the fewest associated members
				List<Integer> minIndices = new ArrayList<>();
				int minCount = Integer.MAX_VALUE;

				for (int i = 0; i < members.size(); i++) {
					if (!excluded.contains(i) && (members.get(i).size() <= minCount)) {
						if (members.get(i).size() < minCount) {
							minIndices.clear();
							minCount = members.get(i).size();
						}
						
						minIndices.add(i);
					}
				}
				
				int minIndex = PRNG.nextItem(minIndices);

				// add associated solution
				if (minCount == 0) {
					if (potentialMembers.get(minIndex).isEmpty()) {
						excluded.add(minIndex);
					} else {
						Solution minSolution = findSolutionWithMinimumDistance(potentialMembers.get(minIndex),
								weights[minIndex]);
						add(minSolution);
						members.get(minIndex).add(minSolution);
						potentialMembers.get(minIndex).remove(minSolution);
					}
				} else {
					if (potentialMembers.get(minIndex).isEmpty()) {
						excluded.add(minIndex);
					} else {
						Solution randSolution = PRNG.nextItem(potentialMembers.get(minIndex));
						add(randSolution);
						members.get(minIndex).add(randSolution);
						potentialMembers.get(minIndex).remove(randSolution);
					}
				}
			}
		}
	}

	/**
	 * Truncates the population to the specified size using the reference-point based nondominated sorting method.
	 */
	@Override
	public void truncate(int size) {
		truncate(size, new RankComparator());
	}
	
	/**
	 * Updates the {@link Niche} and {@link NicheDistance} attributes on all solutions in this population.  Normally,
	 * this is handled by the {@link #truncate(int, Comparator)} method, but this can be called when the calculation is
	 * needed explicitly, such as after initialization.
	 */
	public void updateNiches() {
		updateIdealPoint();
		translateByIdealPoint();
		normalizeByIntercepts(calculateIntercepts());
		associateToReferencePoint(this);
	}
	
	@Override
	public ReferencePointNondominatedSortingPopulation copy() {
		ReferencePointNondominatedSortingPopulation result = new ReferencePointNondominatedSortingPopulation(
				numberOfObjectives, divisions, getComparator());
		
		for (Solution solution : this) {
			result.add(solution.copy());
		}
		
		return result;
	}
	
	@Override
	public void saveState(ObjectOutputStream stream) throws IOException {
		super.saveState(stream);
		stream.writeObject(idealPoint);
		stream.writeObject(weights);
	}
	
	@Override
	public void loadState(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		super.loadState(stream);
		idealPoint = (double[])stream.readObject();
		weights = (double[][])stream.readObject();
	}
	
}
